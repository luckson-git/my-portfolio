EMPLOYEE ATTRITION — POWER BI PROJECT

OPEN THE REPORT
1. Extract the entire ZIP into one folder.
2. In a current Power BI Desktop release, open Employee Attrition.pbip.
   If needed, enable the Power BI Project / enhanced report format preview
   features under File > Options and settings > Options > Preview features.
3. Choose Home > Refresh to populate the model. This project does not include
   a Power BI data cache. Its Power Query loads the embedded CSV snapshot.
4. Use Department and Overtime slicers on each page. Click chart bars to
   filter other visuals. Slicer selections are local to each page.
5. You may save a PBIX copy from Power BI Desktop after refresh.

CONTENTS
Overview: employee records, leavers, attrition share, average tenure;
department, overtime, job role and tenure charts.
Workforce comparisons: role, travel and satisfaction charts plus department
detail with employee counts, leavers, share, tenure and monthly income.

DATA AND DEFINITIONS
Source: WA_Fn-UseC_-HR-Employee-Attrition.csv, supplied by the user.
1,470 unique employee numbers; 237 Yes and 1,233 No attrition records.
No blank source cells. All 35 original columns are preserved.
Attrition share is 237 / 1,470 = 16.1224% in the unfiltered snapshot.
It is not an annual turnover rate: no dates or observation period are supplied.
Tenure groups: 0–1, 2–4, 5–9 and 10+ years at company.
Monthly income is in unspecified source currency units.
Job satisfaction retains its numeric source scale; meanings were not supplied.
Comparisons are descriptive associations and do not establish causes.
Constant fields and the employee identifier are hidden in the report field list.

UPDATING THE SOURCE
The embedded data is a portable snapshot. Replacing the included CSV alone
does not update it. To use a changing file, choose Transform data, open the
Employees query in Advanced Editor, and replace the Snapshot expression
with File.Contents("C:\your-folder\updated.csv"). Keep the remaining steps.
Apply changes and Refresh. The new CSV must have the same columns.

VALIDATION
Source totals, uniqueness, blank cells, embedded payload, JSON parsing,
field bindings and visual canvas bounds were checked programmatically.
The companion PNG is an independently rendered static preview, not a
Power BI screenshot. Native Power BI loading, DAX execution, rendering
and interactions could not be tested in this environment.

Microsoft project documentation:
https://learn.microsoft.com/en-us/power-bi/developer/projects/projects-overview
https://learn.microsoft.com/en-us/power-bi/developer/projects/projects-dataset
